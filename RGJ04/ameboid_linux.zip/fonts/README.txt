These are the kpfonts package, provided by
		Christophe Caignaert		174 rue Charles Lebon
		59650 Villeneuve d'Ascq		France
		c.caignaert@free.fr
		
		for distribution under the GNU General Public License 
		with a specialexception. 
		See 	http://www.gnu.org/licenses/licenses.html 
		for the detail of GPL. 
		
		The special exception is as follows:
		Permission is granted to include kpfonts
		in a document in the Postscript, PDF, or any other
		formats that may be displayed or printed using these
		fonts, regardless of the licensing condition applied
		to the document itself.
		
Each of these files is individually covered by the license :
for licensing purposes, they are not "part of" any larger entity.
I designed the roman fonts from, at first, URW Palladio. 
URW++ is in agreement with the kpfonts project and, consequently, approves it.
For further information, read:		tug.ctan.org/pub/tex-archive/fonts/urw/base35/README.base35
Version 1.0 2007/04/20
Version 1.1 2007/05/04  New oldstyle option, and \sqrt bug fixed
Version 1.11 2007/06/03 Correct bad kernings of 'quote' symbols
Version 1.12 2007/07/14 Uppercase 'Q' bug (oldstyle-SmallCaps) fixed
Version 1.13 2007/07/16 A bug when fixing 1.12 bug fixed (!) 
			Best kerning of 'i' with accent in sf fonts

Christophe Caignaert
